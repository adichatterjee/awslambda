from requests import get

def lambda_handler(event,context):
    ip=get('https://api.ipify.org').text
    print('My public ip is:{}'.format(ip))
    return True